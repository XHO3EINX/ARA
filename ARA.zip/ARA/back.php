<?php
ob_start();
include('token.php');
define('API_KEY',$API_KEY);
function bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
return json_decode($res);
}
}
function sendmessage($chat_id, $text, $mode){
 bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>$text,
 'parse_mode'=>$mode
 ]);
 }
//-----------------------------------//
$MerchantID = $Marchand;
$Amount = $_GET['amount'];
$Authority = $_GET['Authority'];
$user = $_GET['id'];
if ($_GET['Status'] == 'OK'){
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
$result = $client->PaymentVerification(
[
'MerchantID' => $MerchantID,
'Authority' => $Authority,
'Amount' => $Amount,
]
);

if ($result->Status == 100){
echo 'پرداخت با موفقیت انجام شد و حساب شما شارژ شد';
$cbuy = file_get_contents("data/$user/coin.txt");
$cbuy = $cbuy + $Amount;
file_put_contents("data/$user/coin.txt","$cbuy");
sendMessage("$user","✅ پرداخت با موفقیت انجام شد و مبلغ $Amount تومان حساب شما شارژ شد.","html");

$refell = file_get_contents("data/$user/refe.txt");
$refcoin = file_get_contents("data/$refell/coin.txt");
$refcoin = $refcoin + ($Amount/10) ;
file_put_contents("data/$refell/coin.txt","$refcoin");
sendMessage("$refell","✅ زیرمجموعه شما خرید کرد و حساب شما $refcoin تومان شارژ شد.","html");
} else {
echo 'پرداخت شما قبلا ثبت شده است';
}
} else {
echo 'پرداخت انجام نشد';
}
?>